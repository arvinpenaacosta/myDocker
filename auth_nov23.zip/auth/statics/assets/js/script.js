// statics/assets/js/script.js
document.addEventListener('DOMContentLoaded', (event) => {
    console.log('JavaScript is loaded and running.');
});
